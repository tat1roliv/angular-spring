package com.tat1roliv.crudspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
